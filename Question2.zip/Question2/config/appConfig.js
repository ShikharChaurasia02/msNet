let appConfig = {}
appConfig.port = 3000;

module.exports = {
    port:appConfig.port
}