
const calculateControler = require("../controlers/calculateControler");
const webControler = require("../controlers/webControler");
let setRoute = (app)=>{
    app.post('/calculate',calculateControler.calculateEmi);
    app.get('/',webControler.home)
}

module.exports = {
    setRoute:setRoute
}