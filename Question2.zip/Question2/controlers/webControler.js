const fs = require('fs');
let home = (req,res)=>{

    
    let html = fs.readFileSync("web/index.html","utf8");
    
    res.send(html);
}

module.exports = {
    home:home
}