
let calculateEmi = (req,res) =>{
    console.log("in calculate controller");
    let emi = parseInt(req.body.amount)/parseInt(req.body.months);
    res.send(emi.toString());
}

module.exports = {
    calculateEmi:calculateEmi
}