const express = require('express');
const appConfig = require("./config/appConfig")
const fs = require('fs');
const app = express();
// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({extended:true}));

// Parse JSON bodies (as sent by API clients)
app.use(express.json());

const routePath = "./routes";

fs.readdirSync(routePath).forEach((file)=>{
    if(~file.indexOf('.js')){
        let route = require(routePath+'/'+file);
        route.setRoute(app);
    }
});




app.listen(appConfig.port,()=>{
    console.log("listening on port 3000");
});
