﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using BOL;


namespace DAL
{
    public class IdentityDal

    {
        public static string conString = string.Empty;



        static IdentityDal()
        {

            conString = ConfigurationManager.ConnectionStrings["CustomerConnection"].ConnectionString;
        }
        public static bool Validate(string username, string password)
        {

            bool status = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdText = "select * from Customer where UserName=@UserName and Password=@Password";
            SqlCommand cmd = new SqlCommand(cmdText, con);
            cmd.Parameters.Add(new SqlParameter("@UserName", username));
            cmd.Parameters.Add(new SqlParameter("@Password", password));

            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    status = true;

                }

            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return status;
        }

        public static bool Insert(Customer u)
        {
            bool status = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdText = "Insert Into Customer(UserName,Password) values(@UserName,@Password)";
            SqlCommand cmd = new SqlCommand(cmdText, con);

            cmd.Parameters.Add(new SqlParameter("@UserName", u.UserName));
            cmd.Parameters.Add(new SqlParameter("@Password", u.Password));
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                status = true;
            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return status;
        }
    }


}
    


    