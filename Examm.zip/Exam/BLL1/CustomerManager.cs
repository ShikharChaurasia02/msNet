﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL1
{
   public class CustomerManager
    {
        public static bool Valiadte(string username, string passaword)
        {
            return IdentityDal.Validate(username, passaword);
        }
        public static bool Insert(Customer u)
        {
            bool status = false;
            status = IdentityDal.Insert(u);
            return status;
        }

    }
}
