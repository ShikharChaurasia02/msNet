﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
  public class CustomerManager
    {
        public static bool Valiadte(string username, string passaword)
        {
            return IdentityDal.Validate(username, passaword);
        }

    }
}
