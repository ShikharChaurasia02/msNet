﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp1.Models
{
    public class User
    {
        public string UserName{ set; get; }
        public string Password{ set; get; }
    }
}