﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL1;


namespace WebApp1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string username, string password)

        {
            if (CustomerManager.Valiadte(username, password))
            {
                ViewBag.Mesaage = "Success";
                return RedirectToAction("Contact");

            }
            ViewBag.Mesaage = "Invalid Login";
            return Login();

        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            List<Pizza> pizza = new List<Pizza>();
            pizza.Add(new Pizza {Name="corn",Price="500" });
          
            
            
            return View(pizza);
        }

        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(string UserName, string Password)
        {
            Customer newUser = new Customer
            {
                UserName = UserName,
                Password = Password
            };
            if (CustomerManager.Insert(newUser))
            {
                return RedirectToAction("login");
            }
            else
            {
                return View();
            }


          






        }
    }
}