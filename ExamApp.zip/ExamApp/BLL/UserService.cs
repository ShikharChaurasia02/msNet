﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BOL;
namespace BLL
{
    public class UserService
    {
            public static  User validateUser(string email, string password )
        {
            //User u = null;
            
            return  Connection.Authenticate(email,password);
        }

        public static bool AddPizza(PizzaDtls pizza)
        {
            return Admin.AddPizza(pizza);

        }

        public static bool DeletePizza(int id)
        {
            return Admin.DeletePizza(id);
        }

    }

    
}
