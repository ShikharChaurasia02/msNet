import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  url = `assets/data/cust.json`;
  items = [];
  cust=0;
  max_cl=0;
  total=0;
  avg_cl=0;
  constructor(private http: HttpClient) {
    this.http.get(this.url).toPromise().then(data => {
      console.log(data);
      
      for (let key in data)
      {
        if (data.hasOwnProperty(key))
          {
            this.items.push(data[key]);
            this.total=this.total+Number.parseFloat(this.items[this.cust].cl);
            if(this.max_cl<Number.parseFloat(this.items[this.cust].cl))
            {
              this.max_cl=Number.parseFloat(this.items[this.cust].cl);
            }
            this.cust++;
          }
      }
      this.avg_cl=this.total/this.cust;
    });
  }
}
